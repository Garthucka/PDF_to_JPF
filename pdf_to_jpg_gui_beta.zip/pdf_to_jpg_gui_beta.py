import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pdf2image import convert_from_path
from threading import Thread

class PDFtoJPGConverter:
    def __init__(self, root):
        self.root = root
        self.root.title("PDF → JPG конвертер")
        self.root.geometry("600x450")
        self.root.resizable(False, False)
        
        # Переменные
        self.pdf_folder = tk.StringVar()
        self.jpg_folder = tk.StringVar()
        self.poppler_path = tk.StringVar(value=r"C:\poppler\bin")
        self.dpi = tk.IntVar(value=300)
        self.is_converting = False
        
        self.create_widgets()
    
    def create_widgets(self):
        # Заголовок
        title = tk.Label(self.root, text="Пакетное конвертирование PDF → JPG", 
                        font=("Arial", 14, "bold"))
        title.pack(pady=10)
        
        # Рамка для выбора папок
        frame = tk.Frame(self.root)
        frame.pack(pady=10, padx=20, fill="x")
        
        # Папка с PDF
        tk.Label(frame, text="Папка с PDF:").grid(row=0, column=0, sticky="w", pady=5)
        self.pdf_entry = tk.Entry(frame, textvariable=self.pdf_folder, width=50)
        self.pdf_entry.grid(row=0, column=1, padx=5)
        tk.Button(frame, text="Выбрать", command=self.select_pdf_folder).grid(row=0, column=2)
        
        # Папка для JPG
        tk.Label(frame, text="Папка для JPG:").grid(row=1, column=0, sticky="w", pady=5)
        self.jpg_entry = tk.Entry(frame, textvariable=self.jpg_folder, width=50)
        self.jpg_entry.grid(row=1, column=1, padx=5)
        tk.Button(frame, text="Выбрать", command=self.select_jpg_folder).grid(row=1, column=2)
        
        # Путь к Poppler
        tk.Label(frame, text="Путь к Poppler bin:").grid(row=2, column=0, sticky="w", pady=5)
        self.poppler_entry = tk.Entry(frame, textvariable=self.poppler_path, width=50)
        self.poppler_entry.grid(row=2, column=1, padx=5)
        tk.Button(frame, text="Выбрать", command=self.select_poppler).grid(row=2, column=2)
        
        # DPI
        tk.Label(frame, text="Качество (DPI):").grid(row=3, column=0, sticky="w", pady=5)
        self.dpi_spinbox = tk.Spinbox(frame, from_=150, to=600, textvariable=self.dpi, width=10)
        self.dpi_spinbox.grid(row=3, column=1, sticky="w", padx=5)
        
        # Прогресс бар
        self.progress = ttk.Progressbar(self.root, length=560, mode='determinate')
        self.progress.pack(pady=15)
        
        # Текстовое поле для логов
        log_frame = tk.Frame(self.root)
        log_frame.pack(pady=5, padx=20, fill="both", expand=True)
        
        scrollbar = tk.Scrollbar(log_frame)
        scrollbar.pack(side="right", fill="y")
        
        self.log_text = tk.Text(log_frame, height=8, width=70, state="disabled", yscrollcommand=scrollbar.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=self.log_text.yview)
        
        # Кнопка запуска
        self.start_btn = tk.Button(self.root, text="Начать конвертацию", 
                                   command=self.start_conversion, bg="#4CAF50", fg="white",
                                   font=("Arial", 12, "bold"), width=20, state="normal")
        self.start_btn.pack(pady=10)
        
        self.log("Готов к работе. Выберите папки и нажмите 'Начать конвертацию'.")
    
    def select_pdf_folder(self):
        folder = filedialog.askdirectory(title="Выберите папку с PDF")
        if folder:
            self.pdf_folder.set(folder)
            self.log(f"Выбрана папка с PDF: {folder}")
    
    def select_jpg_folder(self):
        folder = filedialog.askdirectory(title="Выберите папку для сохранения JPG")
        if folder:
            self.jpg_folder.set(folder)
            self.log(f"Выбрана папка для JPG: {folder}")
    
    def select_poppler(self):
        folder = filedialog.askdirectory(title="Выберите папку bin из Poppler")
        if folder:
            self.poppler_path.set(folder)
            self.log(f"Путь к Poppler: {folder}")
    
    def log(self, message):
        self.log_text.config(state="normal")
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")
        self.log_text.config(state="disabled")
    
    def start_conversion(self):
        if self.is_converting:
            self.log("Конвертация уже выполняется!")
            return
        
        pdf_dir = self.pdf_folder.get()
        jpg_dir = self.jpg_folder.get()
        poppler = self.poppler_path.get()
        
        if not pdf_dir or not jpg_dir:
            messagebox.showerror("Ошибка", "Выберите обе папки (PDF и JPG)!")
            return
        
        if not os.path.exists(pdf_dir):
            messagebox.showerror("Ошибка", "Папка с PDF не существует!")
            return
        
        if not os.path.exists(poppler):
            messagebox.showwarning("Внимание", 
                "Путь к Poppler некорректен!\n"
                "Скачайте Poppler: https://github.com/oschwartz10612/poppler-windows/releases/\n"
                "И укажите путь к папке bin")
            return
        
        # Блокируем интерфейс
        self.is_converting = True
        self.start_btn.config(state="disabled", text="Конвертация...", bg="#999999")
        
        # Запуск в отдельном потоке
        thread = Thread(target=self.convert_files, args=(pdf_dir, jpg_dir, poppler), daemon=True)
        thread.start()
    
    def convert_files(self, pdf_dir, jpg_dir, poppler):
        try:
            os.makedirs(jpg_dir, exist_ok=True)
            
            pdf_files = [f for f in os.listdir(pdf_dir) if f.lower().endswith('.pdf')]
            total = len(pdf_files)
            
            if total == 0:
                self.log("❌ PDF файлы не найдены в выбранной папке!")
                self.finish_conversion()
                return
            
            self.log(f"📂 Найдено {total} PDF файлов. Начинаю конвертацию...")
            self.progress['maximum'] = total
            self.progress['value'] = 0
            
            success_count = 0
            error_count = 0
            
            for idx, filename in enumerate(pdf_files, 1):
                try:
                    file_path = os.path.join(pdf_dir, filename)
                    images = convert_from_path(file_path, dpi=self.dpi.get(), poppler_path=poppler)
                    
                    for i, image in enumerate(images):
                        jpg_name = f"{os.path.splitext(filename)[0]}_page_{i+1}.jpg"
                        image.save(os.path.join(jpg_dir, jpg_name), "JPEG")
                    
                    self.log(f"[{idx}/{total}] ✓ {filename} ({len(images)} стр.)")
                    success_count += 1
                    
                except Exception as e:
                    self.log(f"[{idx}/{total}] ✗ {filename}: {str(e)}")
                    error_count += 1
                
                self.progress['value'] = idx
                self.root.update_idletasks()
            
            self.log(f"\n✅ Готово! Успешно: {success_count}, Ошибок: {error_count}")
            messagebox.showinfo("Готово", 
                f"Конвертация завершена!\n\n"
                f"Успешно обработано: {success_count}\n"
                f"Ошибок: {error_count}")
        
        except Exception as e:
            self.log(f"❌ Критическая ошибка: {str(e)}")
            messagebox.showerror("Ошибка", f"Произошла ошибка:\n{str(e)}")
        
        finally:
            self.finish_conversion()
    
    def finish_conversion(self):
        # Разблокируем интерфейс
        self.is_converting = False
        self.start_btn.config(state="normal", text="Начать конвертацию", bg="#4CAF50")
        self.progress['value'] = 0

if __name__ == "__main__":
    root = tk.Tk()
    app = PDFtoJPGConverter(root)
    root.mainloop()
